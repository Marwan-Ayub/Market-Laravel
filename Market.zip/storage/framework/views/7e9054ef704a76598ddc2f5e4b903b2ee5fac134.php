<?php $__env->startSection('content'); ?>
<div class="container">
    <br>
    <?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-danger"> <?php echo e($error); ?> </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(session('Result')): ?>
    <div class="alert alert-warning"> <?php echo e(session('Result')); ?></div>
    <?php endif; ?>

    <form action="buy/0/0" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row text-center justify-content-center ">

            <div class="col col-lg-4 col-12">
                <label>Barcode Store</label><br>
                <input name="id" type="text" placeholder="Code Barcode" class="p-2 bg-light border text-left w-100 radius-20"
                    required>
            </div>

            <div class="col col-lg-4 col-12">
                <label>Name Store</label><br>
                <input name="name" type="text" placeholder="Name" class="p-2 bg-light border text-left w-100 radius-20"
                    required>
            </div>


            <div class="col col-lg-4 col-12">
                <label>Supplier</label><br>
                <select name="supplier_id" class="p-2 bg-light border text-left w-100 radius-20">
                    <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($sup->id); ?>"><?php echo e($sup->company_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col col-lg-4 col-12">
                <label>Count Store</label><br>
                <input name="count" type="number" placeholder="Count" class="p-2 bg-light border text-left w-100 radius-20"
                    required>
            </div>

            <div class="col col-lg-4 col-12 mt-2">
                <label>Price Store</label><br>
                <input name="price" type="text" placeholder="price" class="p-2 bg-light border text-left w-100 radius-20"
                    required>
            </div>

            <div class="col col-lg-4 col-12 mt-2">
                <label>Expire Store</label><br>
                <input name="expire_date" type="date" class="p-2 bg-light border text-left w-100 radius-20" required>
            </div>

            <div class="col col-lg-4 col-12 mt-2">
                <label>Is Debt</label><br>
                <select name="is_debt" class="p-2 bg-light border text-left w-100 radius-20">
                    <option value="0">No</option>
                    <option value="1">Yes</option>
                </select>
            </div>

            <div class="col col-lg-4 col-12 mt-2">
                <label>Type</label><br>
                <select name="type" class="p-2 bg-light border text-left w-100 radius-20">
                    <option value="0">Barcode</option>
                    <option value="1">QRcode</option>
                </select>
            </div>



        </div>
        <div class="mt-4 text-center">
            <button class="btn btn-success border w-50 radius-20 col col-lg-4 col-12">Submit</button>
        </div>
    </form>
    <hr>

    <?php echo $__env->make('Layout.Card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="d-flex justify-content-center mt-2">
        <?php echo e($store->links()); ?>

    </div>


</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Market\resources\views/Store.blade.php ENDPATH**/ ?>