<div class="row justify-content-center">
    <?php $__currentLoopData = $store; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card text-center m-1 radius-20">
        <div class="mt-3">
            <?php if($stor->type == 0): ?>
            <?php echo DNS1D::getBarcodeSVG("$stor->id", 'C128', 1,53 ,'dark',true); ?>

            <?php else: ?>
            <?php echo DNS2D::getBarcodeSVG("$stor->id", 'QRCODE'); ?>

            <?php endif; ?>
        </div>
        <div class="card-body text-left">
            <?php if($stor->is_debt == 1): ?>
            <span class="btn btn-warning radius-20 m-2  position-absolute" style="top: 0;left:0;" >Debt !</span>
            <?php endif; ?>
            <p class="card-title">Barcode : <?php echo e($stor->id); ?></p>
            <p class="card-title">Name Store : <?php echo e($stor->name); ?></p>
            <p class="card-title">Supplier : <?php echo e($stor->one_supplier->company_name); ?></p>
            <p class="card-title">Count : <?php echo e($stor->count); ?></p>
            <p class="card-title">Price : <?php echo e(number_format($stor->price , 0 ,'.', '.')); ?> IQD</p>
            <p class="card-title">Expire : <?php echo e($stor->expire_date); ?></p>
            <p class="card-title">Create At : <?php echo e($stor->created_at); ?></p>

            <span class="btn btn-success mt-1" data-toggle="modal" data-target="#y<?php echo e($stor->id); ?>">Edit</span>
            <span class="btn btn-danger mt-1" data-toggle="collapse" data-target="#x<?php echo e($stor->id); ?>">
                Delete
            </span>

            
            <div class="collapse mt-2" id="x<?php echo e($stor->id); ?>">
                <p class="text-danger"> You Want to Delete <?php echo e($stor->name); ?> ?</p>
                <form action="buy/1/<?php echo e($stor->id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-danger radius-20 mt-1 w-100">Yes</button>
                </form>
            </div>

                
            <div class="modal fade" id="y<?php echo e($stor->id); ?>">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="y<?php echo e($stor->id); ?>">Edit Store</h5>
                        </div>
                        <div class="modal-body">
                            <form action="buy/2/<?php echo e($stor->id); ?>" method="POST">
                                <?php echo csrf_field(); ?>

                                <div class="row text-center justify-content-center mt-3">

                                    <div class="col col-lg-4 col-12">
                                        <label>Barcode Store</label><br>
                                        <input name="id" type="text" value="<?php echo e($stor->id); ?>"
                                            placeholder="Barcode" class="p-2 bg-light border text-left w-100 radius-20"
                                            required>
                                    </div>

                                    <div class="col col-lg-4 col-12">
                                        <label>Name Store</label><br>
                                        <input name="name" type="text" value="<?php echo e($stor->name); ?>"
                                            placeholder="Name" class="p-2 bg-light border text-left w-100 radius-20"
                                            required>
                                    </div>
                                    <div class="col col-lg-4 col-12">
                                        <label>Supplier</label><br>
                                        <select name="supplier_id" class="p-2 bg-light border text-left w-100 radius-20">
                                            <option value="<?php echo e($stor->supplier_id); ?>"> <?php echo e($stor->one_supplier->company_name); ?> </option>
                                            <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($sup->id); ?>"> <?php echo e($sup->company_name); ?> </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col col-lg-4 col-12 mt-4">
                                        <label>Count Store</label><br>
                                        <input name="count" type="number" value="<?php echo e($stor->count); ?>"
                                            placeholder="Count"
                                            class="p-2 bg-light border text-left w-100 radius-20" required>
                                    </div>

                                    <div class="col col-lg-4 col-12  mt-4">
                                        <label>Price Store</label><br>
                                        <input name="price" type="text" value="<?php echo e($stor->price); ?>"
                                            placeholder="Price"
                                            class="p-2 bg-light border text-left w-100 radius-20" required>
                                    </div>

                                    <div class="col col-lg-4 col-12  mt-4">
                                        <label>Expire Store</label><br>
                                        <input name="expire_date" type="date" value="<?php echo e($stor->expire_date); ?>"
                                            class="p-2 bg-light border text-left w-100 radius-20" required>
                                    </div>

                                    <div class="col col-lg-4 col-12  mt-4">
                                        <label>Is Debt</label><br>
                                        <select name="is_debt" class="p-2 bg-light border text-left w-100 radius-20">
                                            <?php if($stor->is_debt == 0): ?>
                                                <option value="0">No</option>
                                                <option value="1">Yes</option>
                                            <?php else: ?>
                                                <option value="1">Yes</option>
                                                <option value="0">No</option>
                                            <?php endif; ?>
                                        </select>
                                    </div>

                                    <div class="col col-lg-4 col-12  mt-4">
                                        <label>Type</label><br>
                                        <select name="type" class="p-2 bg-light border text-left w-100 radius-20">
                                            <?php if($stor->type == 0): ?>
                                                <option value="0">Barcode</option>
                                                <option value="1">QRcode</option>
                                            <?php else: ?>
                                                <option value="1">QRcode</option>
                                                <option value="0">Barcode</option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="mt-4 text-center">
                                    <button
                                        class="btn btn-success border w-50 radius-20 col col-lg-4 col-12">Edit
                                    </button>
                                </div>


                            </form>

                        </div>

                    </div>
                </div>
            </div>


        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\Market\resources\views/Layout/Card.blade.php ENDPATH**/ ?>