<div class="text-center p-2 radius-20 shadow ">
    <br>
    <img src="<?php echo e(asset('assets/img/shop.png')); ?>" width="100" alt="">
    <br>
    <br>
    <?php $__currentLoopData = $sold; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <div class="col"><small><?php echo e($item->one_store->name); ?></small></div>
        <div class="col"><small><?php echo e($item->piece); ?></small></div>
        <div class="col"><small><?php echo e(number_format($item->piece * $item->price_at , 0,'.','.')); ?> IQD</small></div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <?php
     $sum = 0;

     for ($i=0; $i <count($sold) ; $i++) {
        $k = $sold[$i]['price_at'] * $sold[$i]['piece'];
        $sum += $k;
     }

    ?>
    <span class="btn btn-success mt-3 radius-20">All Money: <?php echo e(number_format($sum, 0,'.','.')); ?> IQD</span>
</div>
<a href="clean" class="btn btn-danger mt-3 radius-20 w-100">Clean</a>
<?php /**PATH C:\xampp\htdocs\Market\resources\views/Layout/Invoice.blade.php ENDPATH**/ ?>