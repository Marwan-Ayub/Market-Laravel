<?php $__env->startSection('content'); ?>
<div class="container">
    <br>
    <?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-danger"> <?php echo e($error); ?> </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(session('Result')): ?>
    <div class="alert alert-warning"> <?php echo e(session('Result')); ?></div>
    <?php endif; ?>

    <form action="supplier/0/0" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row text-center justify-content-center ">

            <div class="col col-lg-4 col-12">
                <label>Name Supplier</label><br>
                <input name="name" type="text" placeholder="Name" class="p-2 bg-light border text-left w-100 radius-20"
                    required>
            </div>
            <div class="col col-lg-4 col-12">
                <label>Email Supplier</label><br>
                <input name="email" type="email" placeholder="Email"
                    class="p-2 bg-light border text-left w-100 radius-20" required>
            </div>
            <div class="col col-lg-4 col-12">
                <label>Address Supplier</label><br>
                <input name="address" type="text" placeholder="Address"
                    class="p-2 bg-light border text-left w-100 radius-20" required>
            </div>

            <div class="col col-lg-4 col-12  mt-4">
                <label>Phonenumber Supplier</label><br>
                <input name="phonenumber" type="number" placeholder="Phonenumber"
                    class="p-2 bg-light border text-left w-100 radius-20" required>
            </div>
        </div>
        <div class="mt-4 text-center">
            <button class="btn btn-success border w-50 radius-20 col col-lg-4 col-12">Submit</button>
        </div>
    </form>
    <hr>
    <div class="row justify-content-center text-center ">
        <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card bg-light radius-20 m-1">
            <i class="ion-person display-3 text-success"></i>
            <div class="card-body">
                <p class="card-title">Name : <?php echo e($sup->company_name); ?></p>
                <p class="card-title">Email : <?php echo e($sup->email); ?></p>
                <p class="card-title">Address : <?php echo e($sup->address); ?></p>
                <p class="card-title">Phonenumber : <?php echo e($sup->phonenumber); ?></p>

                <span class="btn btn-success" data-toggle="modal" data-target="#y<?php echo e($sup->id); ?>">Edit</span>
                <span class="btn btn-danger" data-toggle="collapse" data-target="#x<?php echo e($sup->id); ?>">
                    Delete
                </span>

                
                <div class="collapse mt-2" id="x<?php echo e($sup->id); ?>">
                    <p class="text-danger"> You Want to Delete <?php echo e($sup->company_name); ?> ?</p>
                    <form action="supplier/1/<?php echo e($sup->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-danger radius-20 mt-1 w-100">Yes</button>
                    </form>
                </div>

                
                <div class="modal fade " id="y<?php echo e($sup->id); ?>">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="y<?php echo e($sup->id); ?>">Edit Supplier</h5>
                            </div>
                            <div class="modal-body">
                                <form action="supplier/2/<?php echo e($sup->id); ?>" method="POST">
                                    <?php echo csrf_field(); ?>

                                    <div class="row text-center justify-content-center mt-3">

                                        <div class="col col-lg-4 col-12">
                                            <label>Name Supplier</label><br>
                                            <input name="name" type="text" value="<?php echo e($sup->company_name); ?>"
                                                placeholder="Name" class="p-2 bg-light border text-left w-100 radius-20"
                                                required>
                                        </div>
                                        <div class="col col-lg-4 col-12">
                                            <label>Email Supplier</label><br>
                                            <input name="email" type="email" value="<?php echo e($sup->email); ?>" placeholder="Email"
                                                class="p-2 bg-light border text-left w-100 radius-20" required>
                                        </div>
                                        <div class="col col-lg-4 col-12">
                                            <label>Address Supplier</label><br>
                                            <input name="address" type="text" value="<?php echo e($sup->address); ?>"
                                                placeholder="Address"
                                                class="p-2 bg-light border text-left w-100 radius-20" required>
                                        </div>

                                        <div class="col col-lg-4 col-12  mt-4">
                                            <label>Phonenumber Supplier</label><br>
                                            <input name="phonenumber" type="number" value="<?php echo e($sup->phonenumber); ?>"
                                                placeholder="Phonenumber"
                                                class="p-2 bg-light border text-left w-100 radius-20" required>
                                        </div>
                                    </div>
                                    <div class="mt-4 text-center">
                                        <button
                                            class="btn btn-success border w-50 radius-20 col col-lg-4 col-12">Edit</button>
                                    </div>


                                </form>

                            </div>

                        </div>
                    </div>
                </div>

            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Market\resources\views/Supplier.blade.php ENDPATH**/ ?>