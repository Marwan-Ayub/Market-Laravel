<?php $__env->startSection('content'); ?>

<div class="container">
    <br>
    <?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-danger"> <?php echo e($error); ?> </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(session('Result')): ?>
    <div class="alert alert-warning"> <?php echo e(session('Result')); ?></div>
    <?php endif; ?>

    <form action="cashier" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row text-center justify-content-center">

            <div class="col col-lg-4 col-12">
                <label>Name Cashier</label><br>
                <input name="name" type="text" placeholder="Name" class="p-2 bg-light border text-left w-100 radius-20"
                    required>
            </div>
            <div class="col col-lg-4 col-12">
                <label>Email Cashier</label><br>
                <input name="email" type="email" placeholder="Email"
                    class="p-2 bg-light border text-left w-100 radius-20" required>
            </div>
            <div class="col col-lg-4 col-12">
                <label>Password Cashier</label><br>
                <input name="password" type="password" placeholder="Password"
                    class="p-2 bg-light border text-left w-100 radius-20" required>
            </div>

            <div class="col col-lg-4 col-12  mt-4">
                <label>Rule Cashier</label><br>
                <select name="rule" class=" bg-light p-2 radius-20 w-100 border">
                    <option value="0">Cashier</option>
                    <option value="1">Admin</option>
                </select>
            </div>
        </div>
        <div class="mt-4 text-center">
            <button class="btn btn-success border w-50 radius-20 col col-lg-4 col-12">Submit</button>
        </div>
    </form>
    <hr>
    <div class="row justify-content-center text-center ">
        <?php $__currentLoopData = $cashiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cashier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card bg-light radius-20 m-3">
            <i class="ion-person display-3 text-success"></i>
            <div class="card-body">
                <p class="card-title">Name : <?php echo e($cashier->name); ?></p>
                <p class="card-title">Email : <?php echo e($cashier->email); ?></p>
                <p class="card-title">Rule : <?php echo e($cashier->rule == 0?'Cashier':'Admin'); ?> </p>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Market\resources\views/cashier.blade.php ENDPATH**/ ?>