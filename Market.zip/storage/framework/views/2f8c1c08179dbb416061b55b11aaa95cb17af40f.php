<table class="table table-hover mt-3 radius-20 table-responsive-sm">
    <thead class="text-center">
        <tr>
            <th>Cashier</th>
            <th>Barcode</th>
            <th>Name</th>
            <th>Price</th>
            <th>Price At</th>
            <th>Expire Date</th>
            <th>Created At</th>
            <th>Sold At</th>
            <th>Piece</th>
            <?php if(Request::segment(1) != 'sellers'): ?>
            <th>Undo</th>
            <?php endif; ?>
        </tr>
    </thead>
    <tbody class="text-center">
        <?php $__currentLoopData = $solds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sold): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($sold->cashier->name); ?></td>
                <td>
                    <?php if($sold->one_store->type == 0): ?>
                    <?php echo DNS1D::getBarcodeSVG("$sold->store_id", 'C128', 1,33 ,'dark',false); ?>

                    <?php else: ?>
                    <?php echo DNS2D::getBarcodeSVG("$sold->store_id", 'QRCODE', 1.2,1.2); ?>

                    <?php endif; ?>
                </td>
                <td><?php echo e($sold->one_store->name); ?></td>
                <td><?php echo e(number_format($sold->one_store->price , 0 ,'.', '.')); ?> IQD</td>
                <td><?php echo e(number_format($sold->price_at , 0 ,'.', '.')); ?> IQD</td>
                <td><?php echo e($sold->one_store->expire_date); ?></td>
                <td><?php echo e($sold->one_store->created_at); ?></td>
                <td><?php echo e($sold->created_at); ?></td>
                <td class="bg-dark text-white border "><?php echo e($sold->piece); ?></td>
                <?php if(Request::segment(1) != 'sellers'): ?>
                <td class="bg-danger text-white border" onclick="undo(`<?php echo e($sold->id); ?>`)"> <i class="ion-arrow-return-left"></i> </td>
                <?php endif; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>



</table>
<?php /**PATH C:\xampp\htdocs\Market\resources\views/Layout/Table.blade.php ENDPATH**/ ?>