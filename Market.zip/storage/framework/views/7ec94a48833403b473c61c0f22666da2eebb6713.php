<?php $__env->startSection('content'); ?>

<?php echo $__env->make('Layout.Card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="d-flex justify-content-center mt-2">
    <?php echo e($store->links()); ?>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Market\resources\views/Notleft.blade.php ENDPATH**/ ?>