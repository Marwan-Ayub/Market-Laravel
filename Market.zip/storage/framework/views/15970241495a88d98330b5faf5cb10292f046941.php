<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <title>Market</title>
</head>

<body>
    <?php if(auth()->guard()->check()): ?>
    <div class="d-flex" id="wrapper">

        <!-- Sidebar -->
        <div class="bg-light border-right" id="sidebar-wrapper">
            <div class="sidebar-heading ml-4"><img src="<?php echo e(asset('assets/img/shop.png')); ?>" width="50px"><span
                    class="ml-3">Market</span> </div>
            <div class="list-group  list-group-flush">
                <?php $__currentLoopData = $sidebar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href=" <?php echo e(Str::lower(str_replace(' ','',$item->name))); ?> " style="position: relative; left:0px;"
                    class=" btn btn-success m-3 radius-20">

                    <i style="position: absolute; left:0px;" class=" <?php echo e($item->icon); ?> ml-3 "></i>
                    <?php echo e($item->name); ?>

                </a>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <form action="logout" method="POST">
                    <?php echo csrf_field(); ?>
                    <button class=" btn btn-danger w-100  rounded-0 mt-2 mb-2 shadow-none">
                        <i class="ion-log-out" style="position: absolute; left:6px;"></i>
                        Logout</button>
                </form>

            </div>
        </div>


        <!-- Page Content -->
        <div id="page-content-wrapper">

            <nav class="navbar navbar-expand-lg navbar-light bg-light  p-2">
                <button class="btn btn-outline-success radius-20" id="menu-toggle">Toggle Menu</button>

            </nav>

            <div class="container-fluid">
                <?php endif; ?>

                <?php echo $__env->yieldContent('content'); ?>

                <?php if(auth()->guard()->check()): ?>
            </div>


        </div>


    </div>

    <?php endif; ?>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    <script>
        $("#menu-toggle").click(function (e) {
            e.preventDefault();
            $("#wrapper").toggleClass("toggled");
        });

    </script>


</body>

</html>
<?php /**PATH C:\xampp\htdocs\Market\resources\views/Layout/layout.blade.php ENDPATH**/ ?>